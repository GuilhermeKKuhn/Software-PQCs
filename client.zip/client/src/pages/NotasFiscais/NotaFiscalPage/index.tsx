export function NotaFiscalPage() {


  return <h2 style={{ padding: 32 }}>NotaFiscalPage</h2>;

  
}