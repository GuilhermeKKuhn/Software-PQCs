export function ProdutoPage() {


  return <h2 style={{ padding: 32 }}>Produto quimico</h2>;

  
}