export function ProdutoFormPage() {


  return <h2 style={{ padding: 32 }}>ProdutoFormPage</h2>;

  
}