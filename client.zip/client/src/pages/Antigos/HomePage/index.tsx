export function HomePage() {
  return (
    <>
      <main className="container">
        <div className="text-center">
          <h1 className="h3 mb-3 fw-normal">HOME PAGE</h1>
        </div>
      </main>
    </>
  );
}
