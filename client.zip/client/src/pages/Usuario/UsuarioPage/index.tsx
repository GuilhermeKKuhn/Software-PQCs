export function UsuarioPage() {


  return <h2 style={{ padding: 32 }}>UsuarioPage</h2>;

  
}