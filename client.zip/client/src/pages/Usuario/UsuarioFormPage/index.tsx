export function UsuarioFormPage() {


  return <h2 style={{ padding: 32 }}>UsuarioFormPage</h2>;

  
}