export function LaboratorioFormPage() {


  return <h2 style={{ padding: 32 }}>LaboratorioFormPage</h2>;

  
}