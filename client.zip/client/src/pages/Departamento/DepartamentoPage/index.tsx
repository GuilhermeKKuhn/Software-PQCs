

export function DepartamentoPage() {


  return <h2 style={{ padding: 32 }}>DepartamentoPage</h2>;

  
}