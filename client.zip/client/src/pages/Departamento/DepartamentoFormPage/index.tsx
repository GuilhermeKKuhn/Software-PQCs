export function DepartamentoFormPage() {


  return <h2 style={{ padding: 32 }}>DeparamentoFormPage</h2>;

  
}