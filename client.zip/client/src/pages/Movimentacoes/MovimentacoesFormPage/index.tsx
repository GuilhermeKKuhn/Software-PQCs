export function MovimentacaoFormPage() {


  return <h2 style={{ padding: 32 }}>MovimentacaoFormPage</h2>;

  
}