export function MovimentacaoPage() {


  return <h2 style={{ padding: 32 }}>MovimentacaoPage</h2>;

  
}