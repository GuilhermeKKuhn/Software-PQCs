export function RelatorioPage() {


  return <h2 style={{ padding: 32 }}>RelatorioPage</h2>;

  
}