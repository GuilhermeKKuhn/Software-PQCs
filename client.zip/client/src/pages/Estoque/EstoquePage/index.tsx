export function EstoquePage() {


  return <h2 style={{ padding: 32 }}>EstoquePage</h2>;

  
}