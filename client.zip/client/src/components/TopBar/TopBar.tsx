export const Topbar = () => {
  return (
    <div className="bg-gray-100 border-b px-6 py-3">
      <div className="flex justify-end">
        <span className="text-sm text-gray-600">Bem-vindo</span>
      </div>
    </div>
  );
};
