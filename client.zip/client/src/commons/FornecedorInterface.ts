export interface IFornecedor {
  id?: number;
  nome: string;
  cnpj: string;
}