export interface IUnidadeMedida {
  id?: number;
  nome: string;
  sigla: string;
}